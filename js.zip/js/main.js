// YGAN Website — Main JS
// Navbar scroll effect
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 50) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});
document.addEventListener('DOMContentLoaded', function() {
  
  // ===== HAMBURGER MENU TOGGLE =====
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobileMenu');
  
  if (hamburger) {
    hamburger.addEventListener('click', function(e) {
      e.stopPropagation();
      mobileMenu.classList.toggle('active');
      hamburger.classList.toggle('active');
    });
  }
  
  // Close menu when clicking outside
  document.addEventListener('click', function(e) {
    if (hamburger && mobileMenu && !hamburger.contains(e.target) && !mobileMenu.contains(e.target)) {
      mobileMenu.classList.remove('active');
      hamburger.classList.remove('active');
    }
  });
  
  // ===== MOBILE DROPDOWN TOGGLE =====
  const dropdownToggles = document.querySelectorAll('.mobile-dropdown-toggle');
  
  dropdownToggles.forEach(toggle => {
    toggle.addEventListener('click', function(e) {
      e.preventDefault();
      const menuId = this.getAttribute('data-toggle');
      const menu = document.getElementById(menuId);
      
      // Close other dropdowns
      dropdownToggles.forEach(t => {
        if (t !== this) {
          t.classList.remove('active');
          const otherId = t.getAttribute('data-toggle');
          const otherMenu = document.getElementById(otherId);
          if (otherMenu) {
            otherMenu.classList.remove('active');
          }
        }
      });
      
      // Toggle current dropdown
      this.classList.toggle('active');
      if (menu) {
        menu.classList.toggle('active');
      }
    });
  });
  
  // Close mobile menu when link is clicked
  const mobileLinks = document.querySelectorAll('.mobile-menu a:not(.mobile-dropdown-toggle)');
  mobileLinks.forEach(link => {
    link.addEventListener('click', function() {
      mobileMenu.classList.remove('active');
      hamburger.classList.remove('active');
      
      // Also close dropdown if open
      dropdownToggles.forEach(t => {
        t.classList.remove('active');
        const menuId = t.getAttribute('data-toggle');
        const menu = document.getElementById(menuId);
        if (menu) {
          menu.classList.remove('active');
        }
      });
    });
  });
  
});


// Mobile menu toggle
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');

if (hamburger && mobileMenu) {
  // Click hamburger to toggle menu
  hamburger.addEventListener('click', (e) => {
    e.stopPropagation();
    mobileMenu.classList.toggle('open');
  });

  // Close menu when clicking a link
  mobileMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
    });
  });

  // Close menu when clicking outside
  document.addEventListener('click', (e) => {
    if (!mobileMenu.contains(e.target) && !hamburger.contains(e.target)) {
      mobileMenu.classList.remove('open');
    }
  });

  // Close menu on resize to desktop
  window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
      mobileMenu.classList.remove('open');
    }
  });
}

// Fade-in on scroll
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.program-card, .value-item, .kra-card, .team-card, .role-card, .impact-card').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(20px)';
  el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
  observer.observe(el);
});



document.querySelectorAll('.gallery-full-item').forEach(function(item) {
      if (item.querySelector('iframe')) {
        item.style.position = 'relative';
        item.style.paddingBottom = '0';
        item.style.height = '240px';
      }
    });
    
    
    const scrollBtn = document.getElementById("scrollBtn");

window.addEventListener("scroll", () => {
  if (window.scrollY > 300) {
    scrollBtn.classList.add("show");
  } else {
    scrollBtn.classList.remove("show");
  }
});

scrollBtn.addEventListener("click", () => {
  if (window.scrollY > window.innerHeight) {
    // Scroll UP
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  } else {
    // Scroll DOWN
    window.scrollTo({
      top: document.body.scrollHeight,
      behavior: "smooth"
    });
  }
});

    const icon = document.getElementById("scrollIcon");

window.addEventListener("scroll", () => {
  if (window.scrollY > 300) {
    scrollBtn.classList.add("show");
    icon.innerText = "↑";
  } else {
    scrollBtn.classList.remove("show");
    icon.innerText = "↓";
  }
});